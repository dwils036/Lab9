/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 9 Exercise 1
 *
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

void set_PWM(double frequency)
{
	static double current_frequency;
	if (frequency != current_frequency)
	{
		if (!frequency) { TCCR0B &= 0x08; }
		else { TCCR0B |= 0x03; }

		if (frequency < 0.954) { OCR0A = 0xFFFF; }
		

		else if (frequency > 31250) { OCR0A = 0x0000; }

		else { OCR0A = (short)(8000000 / (128 * frequency)) - 1; }

		TCNT0 = 0;
		current_frequency = frequency;
	}
}

enum States{Hold, CStat, DStat, EStat}state;

unsigned char bPress = 0x00;

void button_Tick()
{
	bPress = ~PINA & 0x07;
	switch(state)
	{
		case Hold:
		if(bPress == 1)
		{
			state = CStat;
		}
		else if(bPress == 2)
		{
			state = DStat;
		}
		else if(bPress == 4)
		{
			state = EStat;
		}
		else{
			state = Hold;
		}
		break;
		case CStat:
		if(bPress == 1)
		{
			state = CStat;
		}
		else{
			state = Hold;
		}
		break;
		case DStat:
		if(bPress == 2)
		{
			state = DStat;
		}
		else{
			state = Hold;
		}
		break;
		case EStat:
		if(bPress == 4)
		{
			state = EStat;
		}
		else{
			state = Hold;
		}
		break;
	}
	switch(state)
	{
		case Hold:
		set_PWM(0);
		break;
		case CStat:
		set_PWM(261.63);
		break;
		case DStat:
		set_PWM(293.66);
		break;
		case EStat:
		set_PWM(329.63);
		break;
	}
}
void PWM_on()
{
	TCCR0A = (1 << COM0A0 | 1 << WGM00);

	TCCR0B = (1 << WGM02) | (1 << CS01) | (1 << CS00);

	set_PWM(0);
}

void PWM_off()
{
	TCCR0A = 0x00;
	TCCR0B = 0x00;
}


int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // A input initialized to 0xFF
	DDRB = 0xFF; PORTB = 0x00; // B output initialized to 0x00
	PWM_on();
	state = Hold;
	while(1){
		button_Tick();
	}
}
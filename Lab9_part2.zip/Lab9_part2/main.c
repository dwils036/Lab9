/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 9 Exercise 2
 *
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

void set_PWM(double frequency) {
	static double current_frequency;
	if (frequency != current_frequency) {
		if (!frequency) { TCCR0B &= 0x08; }
		else { TCCR0B |= 0x03; }
		

		if (frequency < 0.954) { OCR0A = 0xFFFF; }
		
		else if (frequency > 31250) { OCR0A = 0x0000; }
		
		else { OCR0A = (short)(8000000 / (128 * frequency)) - 1; }

		TCNT0 = 0;
		current_frequency = frequency;
	}
}



enum States{ AStat, BStat, C5Stat, CStat, DStat, EStat, FStat, GStat} state;


unsigned char bPress = 0x00;

const double notes[8] = {261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25};
unsigned char i = 0x00;

void bTick(){
	bPress = ~PINA & 0x07;
	switch(state)
	{
		case CStat:
		if(bPress == 1)
		state = EStat;
		else
		state = CStat;
		break;
		case DStat:
		if(!(bPress == 1))
		state = CStat;
		else
		state = DStat;
		break;
		case EStat:
		if(bPress == 1)
		state = EStat;
		else
		state = FStat;
		break;
		case FStat:
		if(bPress == 2)
		{
			if(i < 7)
			i++;
			state = GStat;
		}
		else if(bPress == 4)
		{
			if(i > 0)
			i--;
			state = BStat;
		}
		else if(bPress == 1)
		state = DStat;
		else
		state = FStat;
		break;
		case GStat:
		state = AStat;
		break;
		case AStat:
		if(bPress == 2)
		state = AStat;
		else
		state = FStat;
		break;
		case BStat:
		state = C5Stat;
		break;
		case C5Stat:
		if(bPress == 4)
		state = C5Stat;
		else
		state = FStat;
		break;
	}
	
	
	switch(state)
	{
		case CStat:
		PWM_off();
		break;
		case DStat:
		break;
		case EStat:
		PWM_on();
		break;
		case FStat:
		break;
		case GStat:
		set_PWM(notes[i]);
		break;
		case AStat:
		break;
		case BStat:
		set_PWM(notes[i]);
		break;
		case C5Stat:
		break;

	}
}

void PWM_on()
{
	TCCR0A = (1 << COM0A0 | 1 << WGM00);

	TCCR0B = (1 << WGM02) | (1 << CS01) | (1 << CS00);

	set_PWM(0);
}

void PWM_off()
{
	TCCR0A = 0x00;
	TCCR0B = 0x00;
}


int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = 0xFF; PORTB = 0x00;
	PWM_on();
	state = CStat;
	while(1){
		bTick();
	}
}
